 <style>
.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  /*background-color: <?php echo $headerfooter; ?>;*/
  text-align: center;
  z-index: 100;	
}
</style>

 <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

<footer class="footer d-block d-sm-none d-md-block d-lg-none bg-white p-0 m-0" style="position: fixed">   
     <div class="btn-group">
		<a class="btn btn-icon font-small-2 mr-1" href="?menu=mchat">
			<span class="badge badge-pill badge-primary badge-up badge-md mt-2 mr-1">5</span>
			<img src="images/ico/chat.png" width="30" class="pb-1"><br>Chat</a>
		<a class="btn btn-icon font-small-2 mr-1" href="?menu=history">
			<img src="images/ico/history.png" width="30" class="pb-1"><br>Riwayat</a>
		<a class="btn btn-icon font-small-3 ml-1 mr-1" href="?menu=home">
			<img src="images/ico/home.png" width="40" class="pb-1"><br>Beranda</a> 
		<a class="btn btn-icon font-small-2 ml-1" href="?menu=product">
			<img src="images/ico/product.png" width="30" class="pb-1"><br>Jual</a>
		<a class="btn btn-icon font-small-2 ml-1" href="?menu=account">
			<img src="images/ico/akun.png" width="30" class="pb-1"><br>Akun</a> 
	 </div> 	
</footer>
 <!-- BEGIN: Footer-->
    <footer class="footer footer-static footer-light bg-white d-none d-xl-block">
        <p class="clearfix blue-grey lighten-2 mb-0">
        <span class="float-md-left mt-25">Hak Cipta di lindungi Undang-Undang &copy; <?php echo date('M,d.Y')?>
        <a class="text-bold-800 grey darken-2" href="#" target="_blank"></a> </span><span class="float-md-right d-none d-md-block"> <img src="images/logo/icon.png" class="rounded-circle img-border box-shadow-1" width="35"></span>
            <!--button class="btn btn-icon text-white scroll-top" type="button"></button-->
        </p>
    </footer>
<!-- END: Footer-->