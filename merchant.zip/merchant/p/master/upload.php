<!-- BEGIN: Content-->
	<div class="content-body mt-2 mb-2"> 
<!-- multi file upload starts -->
  <div class="row">
    <div class="col-12">
       <div class="card">
         <div class="card-header">
             <h4 class="card-title">Upload foto produk di sini</h4>
         </div>
         <div class="card-content">
           <div class="card-body">
             <form action="#" class="dropzone dropzone-area" id="dpz-multiple-files">
               <div class="dz-message">Maks.3 Foto Produk</div>
             </form> 
			 
			 
            <div class="text-bold-600 font-medium-2">Kategori Produk</div>
              <div class="form-group">
                <select class="select2 form-control">
                  <option>Kategori</option>
                  <option>Kategori</option>
                </select>
              </div>
			   
			<fieldset>
             <div class="input-group mb-1">
              <div class="input-group-prepend">
                <span class="input-group-text">Rp</span>
              </div>
              <input type="text" class="form-control" placeholder="Harga produk">
                <div class="input-group-append">
                  <span class="input-group-text">.00</span>
                </div>
             </div>
            </fieldset>
			   
			<button class="btn btn-block btn-success"><i class="fa-solid fa-paper-plane"></i> Upload</button>   
			   
			<h3>Form selanjutnya dan source disamakan di halaman admin</h3>  
                                          
			
           </div>
         </div>
        </div>
      </div>
   </div>
<!-- multi file upload ends -->
	


</div>
<!-- END: Content-->