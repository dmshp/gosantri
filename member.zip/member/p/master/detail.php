<div class="card mt-2">
  <div class="card-body">
	<div class="divider">
	  <div class="divider-text">Informasi</div>
	</div>
    <div class="row mb-5 mt-2">
      <div class="col-12 col-md-5 d-flex align-items-center justify-content-center mb-2 mb-md-0">
         <div class="d-flex align-items-center justify-content-center">
           <img src="images/ads/slide-3.jpg" class="img-fluid">
         </div>
      </div>
           <div class="col-12 col-md-6">
             <h5 class="text-uppercase mb-0">Judul</h5>
             <p class="text-muted font-small-3">by Admin</p>
             <hr>
             <p>Text Information in here</p>
             <hr>
           </div>
    </div>
   </div>
                        
                        
</div>
   
<!-- app ecommerce details end -->

 